function [hyperplane, counters] = perceptron(dataSet,learningRate)

% clear
% close all
% clc
% learningRate=1;
% dataSet = importdata('Letter2Class.data');

[NSamples,NFields] = size(dataSet.data);
MaxIters = 1000;
tolerance = 1e-6;
targetValues = labelsXAtoTarget1minus1 (dataSet);

% let's use the t vector as in Bishop's book and use A as 1 and X as -1 so
% we run the samples and label as such


%% Evaluate the perceptron function %%
prediction = zeros(1,NSamples);
weights = rand(1,NFields + 1)-0.5;

iterating = true;
NIters = 0;
while iterating && (NIters < MaxIters)
    
    counters.TP = 0; % 1 as  1
    counters.TN = 0; %-1 as -1
    counters.FP = 0; % 1 as -1
    counters.FN = 0; %-1 as  1
    
    gradient = zeros(1,NFields + 1);
    for kSample=1:NSamples
        prediction(kSample) = actFun( weights * fixedNonLinTrans(dataSet.data(kSample,:))');
        if prediction(kSample) ~= targetValues(kSample) %% incorrect classification
            gradient = gradient + fixedNonLinTrans(dataSet.data(kSample,:)) * targetValues(kSample);
            
            if targetValues(kSample) == 1 % 1 as  -1
                counters.FP = counters.FP + 1;
            else % -1 as 1
                counters.FN = counters.FN + 1;
            end
            
        else
            if targetValues(kSample) == 1 % 1 as  1
                counters.TP = counters.TP + 1;
            else % -1 as -1
                counters.TN = counters.TN + 1;
            end
        end
    end
    
    %% calculate new weights
    weightsOld = weights;
    for kField=1:NFields+1
        weights(kField) = weights(kField) + learningRate * gradient(kField);
    end
    
    weightsNew = weights;
    
    changeWeight = norm(weightsNew - weightsOld);
    
    if changeWeight < tolerance
        iterating = false;
    end
    NIters = NIters + 1;
    
end
hyperplane = weights;

%% FUNCTIONS %%
    function res = fixedNonLinTrans(a) % Fixed non linear transformation (phi in Bishop's book)
        res = [1 tanh(a)];
    end

    function res = actFun(a) % Activation function (f in Bishop's book)
        if a >= 0
            res = 1;
        else
            res = -1;
        end
    end
end